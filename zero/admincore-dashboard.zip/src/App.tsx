/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  LayoutDashboard,
  BarChart3,
  Users,
  Shield,
  Search,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  Database,
  Bell,
  Trash2,
  X,
  Activity,
  UserCheck,
  Check,
  RefreshCw,
  Zap,
  Info
} from 'lucide-react';

// Type definitions for robust administration
interface Transaction {
  id: string;
  type: 'credit' | 'debit';
  label: string;
  time: string;
  amount: number;
}

interface User {
  id: string;
  name: string;
  role: string;
  email: string;
  status: 'Active' | 'Suspended';
}

interface PerformanceMetric {
  name: string;
  cpu: number;
  memory: number;
  requests: number;
  status: 'Healthy' | 'Heavy Load' | 'Degraded';
}

export default function App() {
  // Navigation & Active States
  const [activeTab, setActiveTab] = useState<'dashboard' | 'analytics' | 'users' | 'teams'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotificationMenu, setShowNotificationMenu] = useState(false);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [showAddTransactionModal, setShowAddTransactionModal] = useState(false);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  
  // Analytics timeframe State (7 Days, 30 Days, 6 Months)
  const [analyticsTimeframe, setAnalyticsTimeframe] = useState<'7d' | '30d' | '6m'>('30d');
  const [selectedChartBar, setSelectedChartBar] = useState<{ day: string; value: number } | null>(null);

  // Simulated Database Latency State
  const [dbNodeLatency, setDbNodeLatency] = useState<number>(14);
  const [isRefreshingLatency, setIsRefreshingLatency] = useState(false);

  // Notifications State
  const [notifications, setNotifications] = useState([
    { id: 'n1', text: 'Critical patch update applied successfully', unread: true, time: '2 mins ago' },
    { id: 'n2', text: 'Database node backup completed', unread: true, time: '1 hour ago' },
    { id: 'n3', text: 'Sarah Jenkins modified teams list policies', unread: false, time: '3 hours ago' }
  ]);

  // Main Dashboard System Ledger / State
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: 't1', type: 'credit', label: 'Stripe Payout Received', time: '2 mins ago', amount: 1200.00 },
    { id: 't2', type: 'debit', label: 'Firebase Usage Fee', time: '1 hour ago', amount: 142.00 },
    { id: 't3', type: 'credit', label: 'Sub-Processor Settlement', time: '3 hours ago', amount: 5000.00 },
    { id: 't4', type: 'credit', label: 'Client Refund Processed', time: '5 hours ago', amount: 20.00 },
    { id: 't5', type: 'debit', label: 'AWS EC2 Router Bill', time: '1 day ago', amount: 480.00 },
    { id: 't6', type: 'credit', label: 'Google Cloud Platform Refund', time: '2 days ago', amount: 350.00 }
  ]);

  // Filter Transaction State (All | Credit | Debit)
  const [ledgerFilter, setLedgerFilter] = useState<'all' | 'credit' | 'debit'>('all');

  // New Transaction Form State
  const [newTxLabel, setNewTxLabel] = useState('');
  const [newTxAmount, setNewTxAmount] = useState('');
  const [newTxType, setNewTxType] = useState<'credit' | 'debit'>('credit');

  // User Management State
  const [users, setUsers] = useState<User[]>([
    { id: 'u1', name: 'Sarah Jenkins', role: 'Security Architect', email: 'sarah.jenkins@admincore.io', status: 'Active' },
    { id: 'u2', name: 'Marcus Vance', role: 'DB Analyst / SRE', email: 'vance.m@admincore.io', status: 'Active' },
    { id: 'u3', name: 'Emma Thorne', role: 'Operations Lead', email: 'emma.t@admincore.io', status: 'Active' },
    { id: 'u4', name: 'Liam Patel', role: 'Full Stack Engineer', email: 'l.patel@admincore.io', status: 'Active' },
    { id: 'u5', name: 'Sophia Lopez', role: 'Data Governance', email: 's.lopez@admincore.io', status: 'Suspended' }
  ]);

  // Team Administrators State (with toggle permissions privileges)
  const [teamPermissions, setTeamPermissions] = useState([
    { id: 'tm1', name: 'Sarah Jenkins', rootAccess: true, auditPerms: true, billingPerms: true },
    { id: 'tm2', name: 'Marcus Vance', rootAccess: false, auditPerms: true, billingPerms: true },
    { id: 'tm3', name: 'Emma Thorne', rootAccess: false, auditPerms: true, billingPerms: false },
    { id: 'tm4', name: 'Liam Patel', rootAccess: false, auditPerms: false, billingPerms: false }
  ]);

  // New User Form State
  const [newUserName, setNewUserName] = useState('');
  const [newUserRole, setNewUserRole] = useState('Developer');
  const [newUserEmail, setNewUserEmail] = useState('');

  // Performance Metrics (Analytics Tab)
  const [perfMetrics, setPerfMetrics] = useState<PerformanceMetric[]>([
    { name: 'US-East Storage Controller', cpu: 42, memory: 68, requests: 1450, status: 'Healthy' },
    { name: 'EU-Central Route Balancer', cpu: 74, memory: 85, requests: 4202, status: 'Heavy Load' },
    { name: 'AP-South API Gateway', cpu: 12, memory: 34, requests: 580, status: 'Healthy' },
    { name: 'Global Database Cluster', cpu: 55, memory: 72, requests: 8400, status: 'Healthy' },
    { name: 'Telemetry Collector Node', cpu: 91, memory: 92, requests: 310, status: 'Degraded' }
  ]);

  // Success Feedback Message Toast State
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
  };

  // Live Metric Math Actions
  const totalRevenue = useMemo(() => {
    const baseRevenue = 42890.00;
    // Sum credit changes to base, subtract debit changes from base
    const currentAdjustments = transactions.reduce((acc, tx) => {
      if (tx.type === 'credit') {
        return acc + tx.amount;
      } else {
        return acc - tx.amount;
      }
    }, 0);
    // Base transaction initial list math correction to let state-derived total start at exact amount $42,890.00
    // Sum of initial list: t1(+1200), t2(-142), t3(+5000), t4(+20), t5(-480), t6(+350) => total initial = +5948.00
    // Therefore baseline is $36,942.00
    return 36942.00 + currentAdjustments;
  }, [transactions]);

  // System warnings calculation state
  const activeSystemWarnings = useMemo(() => {
    let base = 4;
    // Dynamic warnings based on statistics or deleted users/high load
    const degradedCount = perfMetrics.filter(p => p.status === 'Degraded').length;
    return base + degradedCount - 1; 
  }, [perfMetrics]);

  // Refresh Database Latency Simulator
  const refreshLatency = () => {
    setIsRefreshingLatency(true);
    setTimeout(() => {
      const newLatency = Math.floor(Math.random() * 25) + 4; // 4ms to 29ms
      setDbNodeLatency(newLatency);
      setIsRefreshingLatency(false);
      triggerToast(`Database state healthy. Node ping: ${newLatency}ms`);
    }, 800);
  };

  // Handle Garbage Collector Optimization Simulation
  const triggerGarbageCollection = (idx: number) => {
    const updated = [...perfMetrics];
    updated[idx] = {
      ...updated[idx],
      cpu: Math.max(5, Math.floor(updated[idx].cpu * 0.4)),
      memory: Math.max(10, Math.floor(updated[idx].memory * 0.55)),
      status: 'Healthy'
    };
    setPerfMetrics(updated);
    triggerToast(`Optimized ${updated[idx].name}. Garbage collection cycle completed successfully.`);
  };

  // Add Transaction Handler
  const handleAddTransactionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(newTxAmount);
    if (!newTxLabel.trim() || isNaN(amountNum) || amountNum <= 0) {
      alert("Please provide valid description and amount.");
      return;
    }

    const newTx: Transaction = {
      id: `t_${Date.now()}`,
      type: newTxType,
      label: newTxLabel.trim(),
      time: 'Just now',
      amount: amountNum
    };

    setTransactions([newTx, ...transactions]);
    setShowAddTransactionModal(false);
    setNewTxLabel('');
    setNewTxAmount('');
    triggerToast(`Transaction Ledger Updated! Approved $${amountNum.toFixed(2)}`);
  };

  // Add User Handler
  const handleAddUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserEmail.trim()) {
      alert("Please fill all required inputs.");
      return;
    }

    const newUser: User = {
      id: `u_${Date.now()}`,
      name: newUserName.trim(),
      role: newUserRole,
      email: newUserEmail.trim(),
      status: 'Active'
    };

    setUsers([newUser, ...users]);
    setShowAddUserModal(false);
    setNewUserName('');
    setNewUserEmail('');
    triggerToast(`Credentials designated successfully for client ${newUser.name}`);
  };

  // Revoke credentials handler
  const revokeUserCredentials = (id: string, name: string) => {
    setUsers(users.filter(u => u.id !== id));
    triggerToast(`Sovereign credentials revoked instantly for ${name}`);
  };

  // Toggle user permissions switches
  const togglePermission = (id: string, field: 'rootAccess' | 'auditPerms' | 'billingPerms') => {
    setTeamPermissions(teamPermissions.map(p => {
      if (p.id === id) {
        const nextVal = !p[field];
        triggerToast(`Permission security state updated for ${p.name}`);
        return { ...p, [field]: nextVal };
      }
      return p;
    }));
  };

  // Filter lists based on Query
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      // search filter
      const matchesSearch = t.label.toLowerCase().includes(searchQuery.toLowerCase());
      // type filter
      if (ledgerFilter === 'all') return matchesSearch;
      return matchesSearch && t.type === ledgerFilter;
    });
  }, [transactions, ledgerFilter, searchQuery]);

  const filteredUsers = useMemo(() => {
    return users.filter(u => {
      return u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
             u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
             u.role.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [users, searchQuery]);

  // Unread Notification Badge handler
  const unreadCount = notifications.filter(n => n.unread).length;
  const markNotificationsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, unread: false })));
    triggerToast('All platform notifications marked as resolved');
  };

  // Timeframe chart datasets helper
  const chartHeightData = useMemo(() => {
    if (analyticsTimeframe === '7d') {
      return [
        { day: 'Mon 01', value: 870, height: 'h-[85%]' },
        { day: 'Tue 02', value: 430, height: 'h-[45%]' },
        { day: 'Wed 03', value: 210, height: 'h-[25%]' },
        { day: 'Thu 04', value: 640, height: 'h-[65%]' },
        { day: 'Fri 05', value: 920, height: 'h-[92%]' },
        { day: 'Sat 06', value: 500, height: 'h-[50%]' },
        { day: 'Sun 07', value: 310, height: 'h-[35%]' }
      ];
    } else if (analyticsTimeframe === '3m') {
      // Standard values
      return [
        { day: 'Jan', value: 1400, height: 'h-[40%]' },
        { day: 'Feb', value: 2100, height: 'h-[60%]' },
        { day: 'Mar', value: 3100, height: 'h-[90%]' }
      ];
    } else {
      // 30 Days default bar metrics
      return [
        { day: 'Oct 01', value: 310, height: 'h-[30%]' },
        { day: 'Oct 04', value: 520, height: 'h-[50%]' },
        { day: 'Oct 07', value: 410, height: 'h-[40%]' },
        { day: 'Oct 10', value: 710, height: 'h-[70%]' },
        { day: 'Oct 13', value: 890, height: 'h-[85%]' },
        { day: 'Oct 16', value: 460, height: 'h-[45%]' },
        { day: 'Oct 19', value: 200, height: 'h-[20%]' },
        { day: 'Oct 22', value: 610, height: 'h-[60%]' },
        { day: 'Oct 25', value: 780, height: 'h-[75%]' },
        { day: 'Oct 28', value: 420, height: 'h-[40%]' }
      ];
    }
  }, [analyticsTimeframe]);

  return (
    <div id="app-root-container" className="min-h-screen bg-[#0A0A0B] text-slate-300 font-sans flex flex-col md:flex-row overflow-x-hidden select-none antialiased">
      
      {/* Toast Alert Feedback */}
      {successToast && (
        <div id="toast-success-banner" className="fixed bottom-6 right-6 z-50 bg-[#16161A] border border-emerald-500/30 text-white rounded-xl py-3 px-5 flex items-center gap-3 shadow-2xl animate-fade-in-up duration-300 max-w-sm">
          <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
            <Check className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-emerald-400 tracking-wider">Audit Log Confirmed</div>
            <div className="text-xs text-slate-300 mt-0.5">{successToast}</div>
          </div>
        </div>
      )}

      {/* Warning Incident Drawer Detail Modal */}
      {showWarningModal && (
        <div id="warning-incident-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0D0D0E] border border-white/10 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-2 text-rose-400">
                <Shield className="w-5 h-5" />
                <h3 className="text-white font-semibold text-base">Active Security Handlers</h3>
              </div>
              <button 
                id="close-warning-modal-btn" 
                onClick={() => setShowWarningModal(false)}
                className="p-1 rounded-md text-slate-500 hover:text-white hover:bg-white/5"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              The monitoring agent detected anomalies on backend telemetry nodes. Please review node actions and balance router configurations.
            </p>

            <div className="space-y-3 mb-6">
              <div className="bg-rose-500/5 border border-rose-500/10 rounded-lg p-3 flex justify-between items-center">
                <div>
                  <div className="text-xs text-rose-300 font-bold">NODE_09_DEGRADED</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">CPU load exceeded 91% baseline</div>
                </div>
                <button 
                  id="optimise-telemetry-btn"
                  onClick={() => { triggerGarbageCollection(4); setShowWarningModal(false); }}
                  className="px-2 py-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-bold text-[10px] rounded"
                >
                  GC Optimize
                </button>
              </div>
              
              <div className="bg-amber-500/5 border border-amber-500/10 rounded-lg p-3">
                <div className="text-xs text-amber-300 font-bold">STALE_CREDENTIALS</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Sophia Lopez has security level viewer but status suspended</div>
              </div>

              <div className="bg-indigo-500/5 border border-indigo-500/10 rounded-lg p-3">
                <div className="text-xs text-indigo-300 font-bold">BACKUP_SUCCESSFUL</div>
                <div className="text-[10px] text-slate-500 mt-0.5">US-East telemetry snapshot synchronized automatically</div>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <button 
                id="opt-close-btn"
                onClick={() => setShowWarningModal(false)}
                className="px-4 py-2 border border-white/5 bg-[#141417] text-xs font-semibold text-slate-400 rounded-lg hover:bg-white/5 w-full hover:text-white transition-colors"
              >
                Close Security Panel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Transaction Ledger Entry Overlay */}
      {showAddTransactionModal && (
        <div id="add-transaction-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <form id="new-tx-form" onSubmit={handleAddTransactionSubmit} className="bg-[#0D0D0E] border border-white/10 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex justify-between items-center mb-5">
              <h3 id="tx-modal-title" className="text-white font-semibold text-md flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-400" />
                Record Ledger Transaction
              </h3>
              <button 
                id="close-tx-form-btn" 
                type="button"
                onClick={() => setShowAddTransactionModal(false)}
                className="p-1 rounded-md text-slate-500 hover:text-white hover:bg-white/5"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1.5 font-sans tracking-wider">Transaction Destination / Label</label>
                <input 
                  id="tx-input-label" 
                  type="text" 
                  value={newTxLabel}
                  onChange={(e) => setNewTxLabel(e.target.value)}
                  placeholder="e.g. Acme SaaS Subscription" 
                  className="w-full bg-[#161618] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 font-sans"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1.5 font-sans tracking-wider">Transaction Type</label>
                  <select 
                    id="tx-input-type"
                    value={newTxType}
                    onChange={(e) => setNewTxType(e.target.value as 'credit' | 'debit')}
                    className="w-full bg-[#161618] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="credit">Credit (Inflow)</option>
                    <option value="debit">Debit (Outflow)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1.5 font-sans tracking-wider">Amount (USD)</label>
                  <input 
                    id="tx-input-amount" 
                    type="number" 
                    step="0.01"
                    value={newTxAmount}
                    onChange={(e) => setNewTxAmount(e.target.value)}
                    placeholder="250.00" 
                    className="w-full bg-[#161618] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 font-semibold"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                id="cancel-tx-btn"
                type="button" 
                onClick={() => setShowAddTransactionModal(false)}
                className="flex-1 py-2 border border-white/10 text-xs font-semibold text-slate-400 rounded-lg hover:bg-white/5 transition-colors"
              >
                Cancel
              </button>
              <button 
                id="submit-tx-btn"
                type="submit" 
                className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-xs text-white font-semibold rounded-lg transition-colors"
              >
                Authorize Entry
              </button>
            </div>
          </form>
        </div>
      )}

      {/* New User Account Creation Modal */}
      {showAddUserModal && (
        <div id="add-user-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <form id="new-user-form" onSubmit={handleAddUserSubmit} className="bg-[#0D0D0E] border border-white/10 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex justify-between items-center mb-5">
              <h3 id="user-modal-title" className="text-white font-semibold text-md flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-400" />
                Provision User Credentials
              </h3>
              <button 
                id="close-user-form-btn" 
                type="button"
                onClick={() => setShowAddUserModal(false)}
                className="p-1 rounded-md text-slate-500 hover:text-white hover:bg-white/5"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1.5 font-sans tracking-wider">Full User Identity Name</label>
                <input 
                  id="user-input-name" 
                  type="text" 
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  placeholder="e.g. Raymond Devore" 
                  className="w-full bg-[#161618] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1.5 font-sans tracking-wider">Sovereign Email Address</label>
                <input 
                  id="user-input-email" 
                  type="email" 
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  placeholder="e.g. devore.r@admincore.io" 
                  className="w-full bg-[#161618] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1.5 font-sans tracking-wider">Security Access Role</label>
                <select 
                  id="user-input-role"
                  value={newUserRole}
                  onChange={(e) => setNewUserRole(e.target.value)}
                  className="w-full bg-[#161618] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="Administrator">Administrator</option>
                  <option value="Developer">Developer</option>
                  <option value="Systems Operator">Systems Operator</option>
                  <option value="Viewer Support">Viewer Support</option>
                </select>
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                id="cancel-user-btn"
                type="button" 
                onClick={() => setShowAddUserModal(false)}
                className="flex-1 py-2 border border-white/10 text-xs font-semibold text-slate-400 rounded-lg hover:bg-white/5 transition-colors"
              >
                Cancel
              </button>
              <button 
                id="submit-user-btn"
                type="submit" 
                className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-xs text-white font-semibold rounded-lg transition-colors"
              >
                Sync Provision Settings
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Left Navigation Sidebar */}
      <aside id="dashboard-sidebar-navigation" className="w-full md:w-64 border-b md:border-b-0 md:border-r border-white/5 bg-[#0D0D0E] flex flex-col shrink-0">
        <div id="sidebar-header-branding" className="p-6 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-indigo-600 flex items-center justify-center text-white font-bold font-mono text-sm tracking-tight shadow-[0_0_15px_rgba(79,70,229,0.3)]">A</div>
            <span className="text-white font-semibold tracking-tight text-lg">AdminCore</span>
          </div>
          <div className="text-[10px] bg-white/5 hover:bg-white/10 px-2 py-0.5 rounded text-slate-400 font-mono hidden md:block select-none border border-white/5">
            V2.4
          </div>
        </div>
        
        {/* Nav Links section */}
        <nav id="sidebar-navigation-items" className="flex-1 px-4 py-6 space-y-1.5">
          <div id="nav-header-label" className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-4 px-2">Main Menu</div>
          
          <button 
            id="nav-tab-dashboard" 
            onClick={() => { setActiveTab('dashboard'); setSearchQuery(''); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border text-xs font-medium transition-all ${
              activeTab === 'dashboard'
                ? 'bg-white/5 text-white border-white/10 shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]'
                : 'text-slate-400 border-transparent hover:bg-white/5 hover:text-white'
            }`}
          >
            <LayoutDashboard className={`w-4 h-4 ${activeTab === 'dashboard' ? 'text-indigo-400' : 'text-slate-500'}`} />
            Dashboard
          </button>

          <button 
            id="nav-tab-analytics" 
            onClick={() => { setActiveTab('analytics'); setSearchQuery(''); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border text-xs font-medium transition-all ${
              activeTab === 'analytics'
                ? 'bg-white/5 text-white border-white/10 shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]'
                : 'text-slate-400 border-transparent hover:bg-white/5 hover:text-white'
            }`}
          >
            <BarChart3 className={`w-4 h-4 ${activeTab === 'analytics' ? 'text-indigo-400' : 'text-slate-500'}`} />
            Analytics
          </button>

          <button 
            id="nav-tab-users" 
            onClick={() => { setActiveTab('users'); setSearchQuery(''); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border text-xs font-medium transition-all ${
              activeTab === 'users'
                ? 'bg-white/5 text-white border-white/10 shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]'
                : 'text-slate-400 border-transparent hover:bg-white/5 hover:text-white'
            }`}
          >
            <Users className={`w-4 h-4 ${activeTab === 'users' ? 'text-indigo-400' : 'text-slate-500'}`} />
            User Management
          </button>

          <button 
            id="nav-tab-teams" 
            onClick={() => { setActiveTab('teams'); setSearchQuery(''); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border text-xs font-medium transition-all ${
              activeTab === 'teams'
                ? 'bg-white/5 text-white border-white/10 shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]'
                : 'text-slate-400 border-transparent hover:bg-white/5 hover:text-white'
            }`}
          >
            <Shield className={`w-4 h-4 ${activeTab === 'teams' ? 'text-indigo-400' : 'text-slate-500'}`} />
            Security &amp; Teams
          </button>
        </nav>

        {/* Database Node Status Panel at Bottom */}
        <div id="sidebar-db-health-status" className="p-4 mt-auto">
          <div className="bg-indigo-500/5 border border-indigo-500/10 rounded-xl p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-indigo-400 text-[10px] font-bold uppercase tracking-wider">Database Status</span>
              <button 
                id="refresh-latency-ping-btn"
                onClick={refreshLatency} 
                disabled={isRefreshingLatency}
                className="text-[10px] text-slate-500 hover:text-white disabled:opacity-55 flex items-center gap-1"
                title="Ping DB cluster"
              >
                <RefreshCw className={`w-2.5 h-2.5 ${isRefreshingLatency ? 'animate-spin' : ''}`} />
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.7)] animate-pulse"></span>
                <span className="text-[11px] text-white font-medium">live-production</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono bg-white/5 px-1.5 py-0.5 rounded border border-white/5">
                {isRefreshingLatency ? 'pinging' : `${dbNodeLatency}ms`}
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Panel Content Container */}
      <main id="app-main-panel-container" className="flex-1 flex flex-col min-w-0">
        
        {/* Top bar header */}
        <header id="main-header-bar" className="h-16 shrink-0 border-b border-white/5 flex items-center justify-between px-6 md:px-8 bg-[#0D0D0E]">
          <div id="header-breadcrumbs" className="flex items-center gap-3">
            <span className="text-slate-500 text-xs uppercase tracking-wider font-bold hidden sm:inline">AdminCore</span>
            <span className="text-slate-600 text-sm hidden sm:inline">/</span>
            <span className="text-white text-xs uppercase tracking-wider font-bold">
              {activeTab === 'dashboard' && 'Dashboard Overview'}
              {activeTab === 'analytics' && 'Analytics Monitor'}
              {activeTab === 'users' && 'User Governance'}
              {activeTab === 'teams' && 'Security Hierarchy'}
            </span>
          </div>

          <div id="header-interactive-actions" className="flex items-center gap-4 md:gap-6">
            {/* Search container */}
            <div id="header-search-box" className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
              <input 
                id="search-main-input" 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  activeTab === 'users' 
                    ? "Search users..." 
                    : activeTab === 'dashboard' 
                      ? "Search ledger..." 
                      : "Search records..."
                } 
                className="bg-[#161618] border border-white/10 rounded-full py-1.5 pl-9 pr-4 text-xs w-36 sm:w-48 text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-sans tracking-wide transition-all placeholder:text-slate-600"
              />
              {searchQuery && (
                <button 
                  id="clear-search-btn"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* Notification triggers */}
            <div id="header-notification-container" className="relative">
              <button 
                id="trigger-notifications-popover-btn" 
                onClick={() => setShowNotificationMenu(!showNotificationMenu)}
                className="relative p-1.5 rounded-full border border-white/5 bg-[#141417] text-slate-400 hover:text-white hover:bg-white/5 transition-all"
              >
                <Bell className="w-3.5 h-3.5" />
                {unreadCount > 0 && (
                  <span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_6px_rgba(99,102,241,0.9)] animate-pulse"></span>
                )}
              </button>

              {showNotificationMenu && (
                <div id="notification-popover-panel" className="absolute right-0 mt-3 z-40 w-80 bg-[#0D0D0E] border border-white/10 rounded-xl shadow-2xl p-4">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-xs text-white font-bold uppercase tracking-wider">Alert Feed</span>
                    {unreadCount > 0 && (
                      <button 
                        id="mark-all-read-btn" 
                        onClick={markNotificationsRead}
                        className="text-[10px] text-indigo-400 hover:text-indigo-300 font-semibold"
                      >
                        Mark all read
                      </button>
                    )}
                  </div>

                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {notifications.map(no => (
                      <div id={`no-item-${no.id}`} key={no.id} className={`p-2.5 rounded-lg border flex gap-3 transition-colors ${no.unread ? 'bg-indigo-500/5 border-indigo-500/10' : 'bg-[#141417]/40 border-white/5'}`}>
                        <div className="flex-1">
                          <div className={`text-xs ${no.unread ? 'text-white font-medium' : 'text-slate-400'}`}>{no.text}</div>
                          <div className="text-[9px] text-slate-500 mt-1">{no.time}</div>
                        </div>
                        {no.unread && (
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0 mt-1.5"></span>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-white/5 text-center">
                    <span className="text-[10px] text-slate-500 uppercase tracking-widest">Platform Core Realtime Logs</span>
                  </div>
                </div>
              )}
            </div>

            {/* Profile badge */}
            <div id="header-user-badge" className="flex items-center gap-2.5 pl-2 border-l border-white/5">
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-600 to-rose-500 flex items-center justify-center font-bold text-[11px] text-white select-none shadow-md">
                SJ
              </div>
              <div className="hidden lg:flex flex-col">
                <span className="text-xs text-white font-medium leading-tight">Sarah Jenkins</span>
                <span className="text-[9px] text-slate-500 font-mono tracking-wider leading-none">Security Admin</span>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Canvas Area */}
        <div id="main-scrollable-content-area" className="p-5 md:p-8 flex-1 overflow-y-auto space-y-6">
          
          {/* Active Tab View: Dashboard */}
          {activeTab === 'dashboard' && (
            <div id="dashboard-tab-content" className="space-y-6">
              
              {/* Alert Warning Notification Bar if system errors exist */}
              {activeSystemWarnings > 0 && (
                <div id="system-diagnostic-alert-ribbon" className="bg-[#191114] border border-rose-500/10 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-[0_4px_16px_rgba(239,68,68,0.03)] selection:bg-rose-500/20">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-400 shrink-0">
                      <Activity className="w-4 h-4 animate-pulse" />
                    </div>
                    <div>
                      <h4 className="text-white font-medium text-xs">Active anomalies detected in Telemetry Collector Node</h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">Critical host CPU warning requires system operators to trigger micro-optimizations.</p>
                    </div>
                  </div>
                  <button 
                    id="trigger-warning-incident-panel-btn"
                    onClick={() => setShowWarningModal(true)}
                    className="self-start sm:self-center bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold py-1.5 px-3 rounded-lg transition-all border border-rose-500/10"
                  >
                    Diagnose Metrics
                  </button>
                </div>
              )}

              {/* Grid: Stats Column Row */}
              <div id="dashboard-metric-cards-row" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                
                {/* Metric 1 */}
                <div id="metric-total-revenue" className="bg-[#141417] p-5 rounded-2xl border border-white/5 shadow-md flex flex-col justify-between hover:border-white/10 transition-colors">
                  <div>
                    <div className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">Total Net Treasury</div>
                    <div className="text-2xl font-bold font-mono text-white">${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                  </div>
                  <div className="text-[10px] text-emerald-400 mt-4 font-bold flex items-center gap-1">
                    <span className="py-0.5 px-1.5 rounded bg-emerald-500/10 font-sans tracking-wide">+12.5% vs MoM</span>
                    <span className="text-slate-500 font-normal">State-synced</span>
                  </div>
                </div>

                {/* Metric 2 */}
                <div id="metric-active-sessions" className="bg-[#141417] p-5 rounded-2xl border border-white/5 shadow-md flex flex-col justify-between hover:border-white/10 transition-colors">
                  <div>
                    <div className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">Active Client Sessions</div>
                    <div className="text-2xl font-bold text-white font-mono">2,842</div>
                  </div>
                  <div className="text-[10px] text-indigo-400 mt-4 font-bold flex items-center gap-1">
                    <span className="py-0.5 px-1.5 rounded bg-indigo-500/10 font-sans tracking-wide">Live</span>
                    <span className="text-slate-500 font-normal font-mono">Across 5 nodes active</span>
                  </div>
                </div>

                {/* Metric 3 */}
                <div id="metric-database-uptime" className="bg-[#141417] p-5 rounded-2xl border border-white/5 shadow-md flex flex-col justify-between hover:border-white/10 transition-colors">
                  <div>
                    <div className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">Database Cluster Uptime</div>
                    <div className="text-2xl font-bold color-pulse-anim text-emerald-400 font-mono">99.98%</div>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-4 flex items-center gap-1 justify-between">
                    <span className="text-emerald-400 font-bold">Stable performance</span>
                    <button 
                      id="db-quick-ping-metrics"
                      className="text-[9px] text-indigo-400 hover:underline hover:text-indigo-300"
                      onClick={refreshLatency}
                    >
                      Quick Ping
                    </button>
                  </div>
                </div>

                {/* Metric 4 */}
                <div id="metric-system-warnings" className="bg-[#141417] p-5 rounded-2xl border border-white/5 shadow-md flex flex-col justify-between hover:border-white/10 transition-colors cursor-pointer" onClick={() => setShowWarningModal(true)}>
                  <div>
                    <div className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">System Warnings</div>
                    <div className={`text-2xl font-bold font-mono transition-colors ${activeSystemWarnings > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                      {String(activeSystemWarnings).padStart(2, '0')}
                    </div>
                  </div>
                  <div className="text-[10px] mt-4 flex items-center justify-between">
                    <span className={`font-bold ${activeSystemWarnings > 0 ? 'text-rose-400/80 animate-pulse' : 'text-slate-400'}`}>
                      {activeSystemWarnings > 0 ? 'Urgent Review' : 'System Secure'}
                    </span>
                    <span className="text-indigo-400 hover:underline text-[9px]">Details →</span>
                  </div>
                </div>

              </div>

              {/* Mid Section: Chart Analytics Box & Recent Transactions Ledger */}
              <div id="dashboard-mid-panels-grid" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Chart Box Panel (col-span-2) */}
                <div id="user-growth-card-container" className="lg:col-span-2 bg-[#141417] rounded-2xl border border-white/5 p-6 flex flex-col justify-between shadow-md">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h3 id="user-chart-title" className="text-white text-sm font-semibold uppercase tracking-wider">User Activity Growth</h3>
                      <p className="text-[11px] text-slate-500 mt-0.5">Statistical aggregate metric counts across nodes</p>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      {/* Detailed analytics hover display */}
                      {selectedChartBar && (
                        <div id="hovered-bar-metric-popover" className="hidden sm:flex items-center gap-1.5 text-[10px] bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 px-2.5 py-1 rounded">
                          <span className="font-bold">{selectedChartBar.day}:</span>
                          <span className="font-mono font-bold leading-none">{selectedChartBar.value} users</span>
                        </div>
                      )}

                      <select 
                        id="timeframe-select-dropdown" 
                        value={analyticsTimeframe}
                        onChange={(e) => {
                          setAnalyticsTimeframe(e.target.value as '7d' | '30d' | '6m');
                          setSelectedChartBar(null);
                        }}
                        className="bg-[#1C1C20] border border-white/5 focus:ring-1 focus:ring-indigo-500 text-[10px] rounded-lg px-2.5 py-1.5 text-slate-300 font-bold uppercase tracking-wider cursor-pointer"
                      >
                        <option value="7d">Last 7 Days</option>
                        <option value="30d">Last 30 Days</option>
                      </select>
                    </div>
                  </div>

                  {/* Dynamic Height Bars representing state update timelines */}
                  <div id="bar-chart-visualizer-bars" className="flex-1 flex items-end justify-between gap-1 sm:gap-3 px-2 h-48 pb-2 border-b border-white/5">
                    {chartHeightData.map((bar, i) => (
                      <div 
                        id={`chart-bar-col-${i}`}
                        key={i} 
                        onClick={() => setSelectedChartBar(bar)}
                        onMouseEnter={() => setSelectedChartBar(bar)}
                        className={`flex-1 rounded-t cursor-pointer transition-all duration-500 ${
                          selectedChartBar?.day === bar.day 
                            ? 'bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.6)]' 
                            : 'bg-indigo-500/20 hover:bg-indigo-500/40'
                        } ${bar.height}`}
                      ></div>
                    ))}
                  </div>

                  {/* Horizontal Axis Lables */}
                  <div id="chart-horizontal-axis-labels" className="flex justify-between items-center mt-3 text-[10px] text-slate-600 uppercase font-mono tracking-wider px-1">
                    <span>{chartHeightData[0]?.day}</span>
                    <span>{chartHeightData[Math.floor(chartHeightData.length / 2)]?.day}</span>
                    <span>{chartHeightData[chartHeightData.length - 1]?.day}</span>
                  </div>
                </div>

                {/* Recent ledger panel details */}
                <div id="recent-ledger-card-container" className="bg-[#141417] rounded-2xl border border-white/5 p-6 flex flex-col justify-between shadow-md">
                  
                  <div className="mb-4">
                    <div className="flex justify-between items-start mb-1">
                      <h3 id="transactions-header-title" className="text-white text-sm font-semibold uppercase tracking-wider">Transaction Ledger</h3>
                      <button 
                        id="open-add-transaction-modal-btn"
                        onClick={() => setShowAddTransactionModal(true)}
                        className="p-1 rounded bg-indigo-600/10 text-indigo-400 hover:bg-indigo-600/20 hover:text-indigo-300 transition-colors"
                        title="Record Outflow/Inflow"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-relaxed">Audited secure financial operations data</p>

                    {/* Simple filter tabs inside ledger */}
                    <div id="ledger-filter-pills" className="flex gap-1.5 mt-3 pt-1">
                      <button 
                        id="pill-filter-all"
                        onClick={() => setLedgerFilter('all')}
                        className={`px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider rounded transition-colors ${ledgerFilter === 'all' ? 'bg-white/10 text-white' : 'text-slate-500 hover:text-slate-300'}`}
                      >
                        All
                      </button>
                      <button 
                        id="pill-filter-credit"
                        onClick={() => setLedgerFilter('credit')}
                        className={`px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider rounded transition-colors ${ledgerFilter === 'credit' ? 'bg-emerald-500/10 text-emerald-400' : 'text-slate-500 hover:text-slate-300'}`}
                      >
                        Credits
                      </button>
                      <button 
                        id="pill-filter-debit"
                        onClick={() => setLedgerFilter('debit')}
                        className={`px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider rounded transition-colors ${ledgerFilter === 'debit' ? 'bg-rose-500/10 text-rose-400' : 'text-slate-500 hover:text-slate-300'}`}
                      >
                        Debits
                      </button>
                    </div>
                  </div>

                  {/* Scrollable transactions container */}
                  <div id="ledger-scroll-container" className="space-y-3.5 flex-1 overflow-y-auto max-h-60 pr-1 select-none">
                    {filteredTransactions.length === 0 ? (
                      <div id="empty-ledger-view" className="text-center py-8 text-xs text-slate-600 flex flex-col items-center gap-2">
                        <Info className="w-4 h-4 text-slate-700" />
                        No matching transactions found.
                      </div>
                    ) : (
                      filteredTransactions.map((tx) => (
                        <div id={`ledger-item-${tx.id}`} key={tx.id} className="flex items-center gap-3 pb-3 border-b border-white/5 last:border-none last:pb-0">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                            tx.type === 'credit' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'
                          }`}>
                            {tx.type === 'credit' ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownLeft className="w-3.5 h-3.5" />}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="text-xs text-white font-medium truncate">{tx.label}</div>
                            <div className="text-[10px] text-slate-500">{tx.time}</div>
                          </div>

                          <div className={`text-xs font-bold font-mono ${tx.type === 'credit' ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {tx.type === 'credit' ? '+' : '-'}${tx.amount.toFixed(2)}
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Transaction trigger link footer */}
                  <div className="mt-4 pt-3 border-t border-white/5">
                    <button 
                      id="view-all-ledger-actions"
                      onClick={() => setShowAddTransactionModal(true)}
                      className="w-full py-2 bg-[#1C1C20] border border-white/5 rounded-lg text-[9px] font-bold uppercase tracking-widest text-slate-400 hover:bg-white/5 hover:text-white transition-all text-center"
                    >
                      Record Quick Inflow/Outflow
                    </button>
                  </div>

                </div>

              </div>

            </div>
          )}

          {/* Active Tab View: Analytics */}
          {activeTab === 'analytics' && (
            <div id="analytics-tab-content" className="space-y-6">
              
              <div id="analytics-overview-header-board" className="bg-[#141417] p-6 rounded-2xl border border-white/5">
                <h3 className="text-white text-sm font-semibold uppercase tracking-wider mb-2">Platform Router Telemetry</h3>
                <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                  Active monitoring metrics across systems nodes. Operators must manually balance memory constraints or execute deep micro-optimizations for Degraded performance nodes.
                </p>
              </div>

              {/* Server Nodes Load Monitoring Grid */}
              <div id="system-nodes-telemetry-grid" className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {perfMetrics.map((node, i) => (
                  <div id={`system-node-item-${i}`} key={i} className="bg-[#141417] border border-white/5 rounded-2xl p-5 shadow-sm space-y-4 hover:border-white/10 transition-colors">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-white text-xs font-semibold">{node.name}</h4>
                        <span className="text-[9px] text-slate-500 font-mono">ID: NODE_%23{100 + i}_CLUSTER</span>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                        node.status === 'Healthy' 
                          ? 'bg-emerald-500/10 text-emerald-400' 
                          : node.status === 'Heavy Load'
                            ? 'bg-amber-500/10 text-amber-400'
                            : 'bg-rose-500/10 text-rose-400 animate-pulse'
                      }`}>
                        {node.status}
                      </span>
                    </div>

                    {/* Progress bars to display load levels */}
                    <div className="space-y-2.5">
                      {/* CPU slider bar */}
                      <div>
                        <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                          <span>Node Host CPU</span>
                          <span className={`font-mono font-semibold ${node.cpu > 80 ? 'text-rose-400' : 'text-slate-300'}`}>{node.cpu}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-[#1C1C20] rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-700 ${node.cpu > 80 ? 'bg-rose-500' : node.cpu > 60 ? 'bg-amber-500' : 'bg-indigo-500'}`}
                            style={{ width: `${node.cpu}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Memory load bar */}
                      <div>
                        <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                          <span>Allocated Memory RAM</span>
                          <span className="font-mono font-semibold text-slate-300">{node.memory}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-[#1C1C20] rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-[#52525B] transition-all duration-700"
                            style={{ width: `${node.memory}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    {/* Requests/sec indicators */}
                    <div className="pt-3 border-t border-white/5 flex justify-between items-center text-[10px]">
                      <div>
                        <span className="text-slate-500 block uppercase tracking-wider text-[8px] font-bold">Network Traffic</span>
                        <span className="font-mono font-bold text-white">{node.requests} rps</span>
                      </div>

                      <button 
                        id={`gc-optimize-node-btn-${i}`}
                        onClick={() => triggerGarbageCollection(i)}
                        className="py-1 px-2.5 rounded bg-white/5 hover:bg-indigo-600 hover:text-white border border-white/10 text-[9px] font-bold text-slate-400 transition-all uppercase tracking-wider"
                      >
                        Optimize Node
                      </button>
                    </div>

                  </div>
                ))}
              </div>

            </div>
          )}

          {/* Active Tab View: Users */}
          {activeTab === 'users' && (
            <div id="users-tab-content" className="space-y-6">
              
              <div id="users-section-header" className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#141417] p-6 rounded-2xl border border-white/5">
                <div>
                  <h3 id="users-card-title" className="text-white text-sm font-semibold uppercase tracking-wider mb-1">Operational Credentials List</h3>
                  <p className="text-xs text-slate-500">Assign sovereign cloud credentials to platform developers</p>
                </div>

                <button 
                  id="open-add-user-modal-btn"
                  onClick={() => setShowAddUserModal(true)}
                  className="sm:self-center bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-2 px-4 rounded-xl transition-all shadow-md flex items-center gap-2 self-start"
                >
                  <Plus className="w-4 h-4" />
                  Privilege User
                </button>
              </div>

              {/* Users table list */}
              <div id="users-table-container" className="bg-[#141417] rounded-2xl border border-white/5 overflow-hidden shadow-sm">
                <div className="overflow-x-auto min-w-full">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-white/5 text-[9px] uppercase tracking-wider font-bold text-slate-500">
                        <th className="py-4 px-6">Identified Person</th>
                        <th className="py-4 px-6">Security Access Role</th>
                        <th className="py-4 px-6">Active Email</th>
                        <th className="py-4 px-6">Credentials Status</th>
                        <th className="py-4 px-6 text-right">Revocation Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                      {filteredUsers.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-12 text-center text-slate-500 text-xs">
                            No credentials match the search query parameters.
                          </td>
                        </tr>
                      ) : (
                        filteredUsers.map((user) => (
                          <tr id={`user-row-u-%23${user.id}`} key={user.id} className="hover:bg-white/5 transition-colors">
                            <td className="py-4 px-6">
                              <div className="flex items-center gap-3">
                                <div className="w-7 h-7 rounded-lg bg-indigo-600/10 text-indigo-400 flex items-center justify-center font-bold text-[10px]">
                                  {user.name.split(' ').map(n=>n[0]).join('')}
                                </div>
                                <span className="text-white font-medium">{user.name}</span>
                              </div>
                            </td>
                            <td className="py-4 px-6 text-slate-400">{user.role}</td>
                            <td className="py-4 px-6 font-mono text-[11px] text-slate-400">{user.email}</td>
                            <td className="py-4 px-6">
                              <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                                user.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                              }`}>
                                <span className={`w-1 h-1 rounded-full ${user.status === 'Active' ? 'bg-emerald-400' : 'bg-rose-400'}`}></span>
                                {user.status}
                              </span>
                            </td>
                            <td className="py-4 px-6 text-right">
                              <button 
                                id={`revoke-user-btn-${user.id}`}
                                onClick={() => revokeUserCredentials(user.id, user.name)}
                                className="text-[10px] text-rose-500 hover:text-rose-400 font-bold uppercase tracking-wider bg-rose-500/5 hover:bg-rose-500/10 transition-colors py-1 px-2.5 rounded"
                              >
                                Revoke
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* Active Tab View: Teams */}
          {activeTab === 'teams' && (
            <div id="teams-tab-content" className="space-y-6">
              
              <div id="teams-intro-card" className="bg-[#141417] p-6 rounded-2xl border border-white/5">
                <h3 className="text-white text-sm font-semibold uppercase tracking-wider mb-2">Administrative Access Controls</h3>
                <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                  Set security flags and toggle active access keys. These controls impact live-production telemetry layers instantly. Guard root authorization keys carefully.
                </p>
              </div>

              {/* Administrative Permissions Table */}
              <div id="permissions-grid-controls" className="bg-[#141417] rounded-2xl border border-white/5 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-white/5 text-[9px] uppercase tracking-wider font-bold text-slate-500">
                        <th className="py-4 px-6">System Operator</th>
                        <th className="py-4 px-6 text-center">Root Command Flag (sudo)</th>
                        <th className="py-4 px-6 text-center">Audit Analytics Logs</th>
                        <th className="py-4 px-6 text-center">Billing Settlement Key</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                      {teamPermissions.map((item) => (
                        <tr id={`team-perm-row-${item.id}`} key={item.id} className="hover:bg-white/5 transition-colors">
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-3">
                              <div className="w-7 h-7 rounded-sm bg-indigo-600 text-white font-bold flex items-center justify-center text-[10px]">
                                {item.name.charAt(0)}
                              </div>
                              <span className="text-white font-medium">{item.name}</span>
                            </div>
                          </td>
                          
                          {/* Sudo check indicator */}
                          <td className="py-4 px-6 text-center">
                            <button 
                              id={`toggle` + item.id + `-rootAccess`}
                              onClick={() => togglePermission(item.id, 'rootAccess')}
                              className={`mx-auto w-10 h-5 rounded-full p-0.5 transition-colors ${item.rootAccess ? 'bg-indigo-600' : 'bg-[#1C1C20]'}`}
                            >
                              <div className={`w-4 h-4 rounded-full bg-white transition-transform ${item.rootAccess ? 'translate-x-5' : 'translate-x-0'}`}></div>
                            </button>
                          </td>

                          {/* Audit check indicator */}
                          <td className="py-4 px-6 text-center">
                            <button 
                              id={`toggle` + item.id + `-auditPerms`}
                              onClick={() => togglePermission(item.id, 'auditPerms')}
                              className={`mx-auto w-10 h-5 rounded-full p-0.5 transition-colors ${item.auditPerms ? 'bg-indigo-600' : 'bg-[#1C1C20]'}`}
                            >
                              <div className={`w-4 h-4 rounded-full bg-white transition-transform ${item.auditPerms ? 'translate-x-5' : 'translate-x-0'}`}></div>
                            </button>
                          </td>

                          {/* Billing indicator */}
                          <td className="py-4 px-6 text-center">
                            <button 
                              id={`toggle` + item.id + `-billingPerms`}
                              onClick={() => togglePermission(item.id, 'billingPerms')}
                              className={`mx-auto w-10 h-5 rounded-full p-0.5 transition-colors ${item.billingPerms ? 'bg-indigo-600' : 'bg-[#1C1C20]'}`}
                            >
                              <div className={`w-4 h-4 rounded-full bg-white transition-transform ${item.billingPerms ? 'translate-x-5' : 'translate-x-0'}`}></div>
                            </button>
                          </td>

                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* Footer Branding Info */}
          <footer id="app-footer-bar" className="flex flex-col sm:flex-row justify-between items-center pt-2 pb-1 border-t border-white/5 opacity-40 text-slate-500 gap-2">
            <span id="footer-version-label" className="text-[10px] uppercase font-mono tracking-widest text-center sm:text-left">Admin Dashboard V2.4 // System Core</span>
            <span id="footer-credits-label" className="text-[10px] uppercase font-mono tracking-widest text-center sm:text-right">Built with Vite + React 19</span>
          </footer>

        </div>

      </main>

    </div>
  );
}
